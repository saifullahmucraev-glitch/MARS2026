const http = require("http");
const crypto = require("crypto");
const { WebSocketServer } = require("ws");
const { Pool } = require("pg");

const PORT = Number(process.env.PORT || 10000);
const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL is required");
  process.exit(1);
}

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.PGSSL === "false" ? false : { rejectUnauthorized: false }
});

const clients = new Map(); // userId -> ws
const sessions = new Map(); // token -> userId
const loginAttempts = new Map();

function json(res, code, body) {
  res.writeHead(code, {"content-type":"application/json; charset=utf-8"});
  res.end(JSON.stringify(body));
}

function scryptHash(password, salt) {
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, 64, {N: 16384, r: 8, p: 1}, (err, key) => {
      if (err) reject(err);
      else resolve(key.toString("hex"));
    });
  });
}

async function verifyPassword(password, salt, expected) {
  const got = await scryptHash(password, salt);
  return crypto.timingSafeEqual(Buffer.from(got, "hex"), Buffer.from(expected, "hex"));
}

function cleanUser(row) {
  return {
    id: String(row.id),
    username: row.username,
    name: row.name,
    avatar: row.avatar || "👤",
    online: clients.has(String(row.id))
  };
}

function send(ws, obj) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(obj));
}

async function setup() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      username TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      avatar TEXT,
      password_hash TEXT NOT NULL,
      password_salt TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS contacts (
      user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      contact_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      PRIMARY KEY (user_id, contact_id)
    );
    CREATE TABLE IF NOT EXISTS messages (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      text TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      delivered_at TIMESTAMPTZ,
      read_at TIMESTAMPTZ,
      edited_at TIMESTAMPTZ,
      deleted_at TIMESTAMPTZ
    );
    CREATE INDEX IF NOT EXISTS messages_pair_idx
      ON messages(sender_id, recipient_id, created_at);
    CREATE TABLE IF NOT EXISTS reactions (
      message_id UUID NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
      user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      emoji TEXT NOT NULL,
      PRIMARY KEY (message_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS groups (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS group_members (
      group_id UUID NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
      user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      PRIMARY KEY (group_id, user_id)
    );
  `);
}

async function contactsFor(userId) {
  const {rows} = await pool.query(`
    SELECT u.* FROM users u
    JOIN contacts c ON c.contact_id=u.id
    WHERE c.user_id=$1
    ORDER BY u.username
  `, [userId]);
  return rows.map(cleanUser);
}

async function authUser(token) {
  const id = sessions.get(token);
  if (!id) return null;
  const {rows} = await pool.query("SELECT * FROM users WHERE id=$1", [id]);
  return rows[0] || null;
}

async function broadcastPresence(userId, online) {
  const {rows} = await pool.query(`
    SELECT user_id FROM contacts WHERE contact_id=$1
    UNION
    SELECT contact_id AS user_id FROM contacts WHERE user_id=$1
  `, [userId]);
  for (const r of rows) {
    const c = clients.get(String(r.user_id));
    send(c, {type:"presence", userId:String(userId), online});
  }
}

async function handle(ws, p) {
  let user = ws.user;

  if (p.type === "auth_register") {
    const username = String(p.username||"").trim().toLowerCase();
    const name = String(p.name||"").trim();
    const password = String(p.password||"");
    if (!/^[a-z0-9_.-]{3,32}$/.test(username) || !name || password.length < 12)
      return send(ws,{type:"auth_error",message:"Проверь логин, имя и пароль (пароль от 12 символов)."});

    const ip = ws._socket.remoteAddress || "unknown";
    const now = Date.now(), a = loginAttempts.get(ip) || {n:0,t:now};
    if (now-a.t > 10*60*1000) {a.n=0;a.t=now;}
    if (++a.n > 10) return send(ws,{type:"auth_error",message:"Слишком много попыток. Попробуй позже."});
    loginAttempts.set(ip,a);

    const salt = crypto.randomBytes(16).toString("hex");
    const hash = await scryptHash(password, salt);
    try {
      const {rows} = await pool.query(
        "INSERT INTO users(username,name,avatar,password_hash,password_salt) VALUES($1,$2,$3,$4,$5) RETURNING *",
        [username,name,p.avatar||"👤",hash,salt]
      );
      user = rows[0];
      ws.user=user;
      const token=crypto.randomBytes(32).toString("hex");
      sessions.set(token,String(user.id));
      clients.set(String(user.id),ws);
      send(ws,{type:"auth_ok",token,user:cleanUser(user),contacts:[]});
      await broadcastPresence(user.id,true);
    } catch(e) {
      send(ws,{type:"auth_error",message:e.code==="23505"?"Такой логин уже занят.":"Не удалось создать аккаунт."});
    }
    return;
  }

  if (p.type === "auth_login") {
    const username=String(p.username||"").trim().toLowerCase(), password=String(p.password||"");
    const {rows}=await pool.query("SELECT * FROM users WHERE username=$1",[username]);
    if (!rows[0] || !(await verifyPassword(password,rows[0].password_salt,rows[0].password_hash)))
      return send(ws,{type:"auth_error",message:"Неверный логин или пароль."});
    user=rows[0]; ws.user=user;
    const token=crypto.randomBytes(32).toString("hex");
    sessions.set(token,String(user.id)); clients.set(String(user.id),ws);
    send(ws,{type:"auth_ok",token,user:cleanUser(user),contacts:await contactsFor(user.id)});
    await broadcastPresence(user.id,true);
    return;
  }

  if (p.type === "session") {
    const u=await authUser(String(p.token||""));
    if (!u) return send(ws,{type:"auth_error",message:"Сессия истекла."});
    user=u; ws.user=u; clients.set(String(u.id),ws);
    send(ws,{type:"session_ok",user:cleanUser(u),contacts:await contactsFor(u.id)});
    return;
  }

  if (!user) return send(ws,{type:"error",message:"Сначала войди в аккаунт."});
  const uid=String(user.id);

  if (p.type === "list_contacts") return send(ws,{type:"contacts",contacts:await contactsFor(uid)});

  if (p.type === "add_contact") {
    const username=String(p.username||"").trim().toLowerCase();
    const {rows}=await pool.query("SELECT * FROM users WHERE username=$1",[username]);
    if (!rows[0]) return send(ws,{type:"error",message:"Пользователь не найден."});
    if (String(rows[0].id)===uid) return send(ws,{type:"error",message:"Нельзя добавить себя."});
    await pool.query("INSERT INTO contacts(user_id,contact_id) VALUES($1,$2) ON CONFLICT DO NOTHING",[uid,rows[0].id]);
    await pool.query("INSERT INTO contacts(user_id,contact_id) VALUES($1,$2) ON CONFLICT DO NOTHING",[rows[0].id,uid]);
    send(ws,{type:"contacts",contacts:await contactsFor(uid)});
    const other=clients.get(String(rows[0].id));
    send(other,{type:"contacts",contacts:await contactsFor(rows[0].id)});
    return;
  }

  if (p.type === "remove_contact") {
    await pool.query("DELETE FROM contacts WHERE (user_id=$1 AND contact_id=$2) OR (user_id=$2 AND contact_id=$1)",[uid,p.userId]);
    return send(ws,{type:"contacts",contacts:await contactsFor(uid)});
  }

  if (p.type === "history") {
    const other=String(p.withUser||"");
    const {rows}=await pool.query(`
      SELECT id,sender_id AS "from",recipient_id AS "to",text,created_at AS time,delivered_at,read_at
      FROM messages
      WHERE (sender_id=$1 AND recipient_id=$2) OR (sender_id=$2 AND recipient_id=$1)
      ORDER BY created_at ASC LIMIT 1000
    `,[uid,other]);
    await pool.query("UPDATE messages SET delivered_at=COALESCE(delivered_at,now()) WHERE sender_id=$1 AND recipient_id=$2",[other,uid]);
    send(ws,{type:"history",withUser:other,messages:rows});
    return;
  }

  if (p.type === "send_message") {
    const to=String(p.to||""), text=String(p.text||"").trim();
    if (!to || !text || text.length>10000) return send(ws,{type:"error",message:"Некорректное сообщение."});
    const allowed=await pool.query("SELECT 1 FROM contacts WHERE user_id=$1 AND contact_id=$2",[uid,to]);
    if (!allowed.rowCount) return send(ws,{type:"error",message:"Пользователь не в контактах."});
    const {rows}=await pool.query("INSERT INTO messages(sender_id,recipient_id,text) VALUES($1,$2,$3) RETURNING id,sender_id AS \"from\",recipient_id AS \"to\",text,created_at AS time",[uid,to,text]);
    const msg=rows[0];
    send(ws,{type:"message",message:msg});
    const other=clients.get(to);
    if (other) {
      await pool.query("UPDATE messages SET delivered_at=now() WHERE id=$1",[msg.id]);
      msg.delivered_at=new Date().toISOString();
    }
    send(other,{type:"message",message:msg});
    return;
  }

  if (["call_invite","call_accept","call_reject","call_end","webrtc_offer","webrtc_answer","ice_candidate"].includes(p.type)) {
    const to=String(p.to||"");
    const target=clients.get(to);
    if (target) send(target,{...p,from:uid});
    return;
  }

  if (p.type === "typing") {
    const target=clients.get(String(p.to||""));
    send(target,{type:"typing",from:uid,typing:!!p.typing});
    return;
  }

  if (p.type === "read") {
    await pool.query("UPDATE messages SET read_at=now() WHERE id=$1 AND recipient_id=$2",[p.messageId,uid]);
    const {rows}=await pool.query("SELECT sender_id FROM messages WHERE id=$1",[p.messageId]);
    if (rows[0]) send(clients.get(String(rows[0].sender_id)),{type:"read",messageId:p.messageId,by:uid});
    return;
  }

  if (p.type === "reaction") {
    const emoji=String(p.emoji||"").slice(0,8);
    await pool.query(`
      INSERT INTO reactions(message_id,user_id,emoji) VALUES($1,$2,$3)
      ON CONFLICT(message_id,user_id) DO UPDATE SET emoji=EXCLUDED.emoji
    `,[p.messageId,uid,emoji]);
    return send(ws,{type:"reaction_ok",messageId:p.messageId,emoji});
  }
}

const server=http.createServer(async (req,res)=>{
  if (req.url==="/health") return json(res,200,{ok:true,service:"MARS Server",version:"1.0"});
  if (req.url==="/") return json(res,200,{service:"MARS Server",status:"online"});
  return json(res,404,{error:"not found"});
});

const wss=new WebSocketServer({server});
wss.on("connection",(ws)=>{
  ws.on("message",async data=>{
    try { await handle(ws,JSON.parse(data.toString())); }
    catch(e){ console.error(e); send(ws,{type:"error",message:"Ошибка сервера."}); }
  });
  ws.on("close",async()=>{
    if (ws.user) {
      const uid=String(ws.user.id);
      if (clients.get(uid)===ws) clients.delete(uid);
      await broadcastPresence(uid,false).catch(()=>{});
    }
  });
  send(ws,{type:"server_info",name:"MARS Server",version:"1.0"});
});

setup().then(()=>{
  server.listen(PORT,()=>console.log(`MARS Server listening on ${PORT}`));
}).catch(e=>{console.error(e);process.exit(1)});
